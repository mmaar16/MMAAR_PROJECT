var searchData=
[
  ['read_5ffile',['read_file',['../namespaceindex.html#a9fd46cc5d3429e40ff6565d2cf395ccc',1,'index']]]
];
