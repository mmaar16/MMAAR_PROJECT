var searchData=
[
  ['changealpha',['changeAlpha',['../namespaceindex.html#a543d7bb682f24e084a3b7c60c7583e57',1,'index']]],
  ['changergba',['changeRGBA',['../namespaceindex.html#ab84c050aff99b8233b940e4610f96f46',1,'index']]]
];
